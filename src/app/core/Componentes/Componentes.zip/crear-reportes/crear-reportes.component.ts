import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-reportes',
  templateUrl: './crear-reportes.component.html',
  styleUrls: ['./crear-reportes.component.css']
})
export class CrearReportesComponent {

}
