import { Component } from '@angular/core';

@Component({
  selector: 'app-regitro-de-aprendiz',
  templateUrl: './regitro-de-aprendiz.component.html',
  styleUrls: ['./regitro-de-aprendiz.component.css']
})
export class RegitroDeAprendizComponent {

}
