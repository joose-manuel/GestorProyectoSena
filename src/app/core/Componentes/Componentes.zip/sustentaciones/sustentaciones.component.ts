import { Component } from '@angular/core';

@Component({
  selector: 'app-sustentaciones',
  templateUrl: './sustentaciones.component.html',
  styleUrls: ['./sustentaciones.component.css']
})
export class SustentacionesComponent {

}
