import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-coordinador',
  templateUrl: './menu-coordinador.component.html',
  styleUrls: ['./menu-coordinador.component.css']
})
export class MenuCoordinadorComponent {

}
