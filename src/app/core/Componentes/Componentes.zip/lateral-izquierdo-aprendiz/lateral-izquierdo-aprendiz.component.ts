import { Component } from '@angular/core';

@Component({
  selector: 'app-lateral-izquierdo-aprendiz',
  templateUrl: './lateral-izquierdo-aprendiz.component.html',
  styleUrls: ['./lateral-izquierdo-aprendiz.component.css']
})
export class LateralIzquierdoAprendizComponent {

}
